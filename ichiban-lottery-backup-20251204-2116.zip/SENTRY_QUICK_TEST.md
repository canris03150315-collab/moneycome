# 🧪 Sentry 快速測試指南

## ✅ 後端已啟動！

現在可以測試 Sentry 了：

---

## 📋 **測試步驟**

### **1. 刷新瀏覽器**
- 打開 http://localhost:5173
- 按 `Ctrl + Shift + R` 強制刷新

### **2. 找到測試按鈕**
- 在首頁頂部會看到一個**紫色框**
- 標題：🧪 Sentry 測試（僅開發環境）
- 裡面有一個紫色按鈕：**Break the world**

### **3. 點擊按鈕**
- 點擊 "Break the world" 按鈕
- 會看到錯誤訊息彈出

### **4. 檢查 Console**
- 按 `F12` 打開開發者工具
- 切換到 Console 標籤
- 應該會看到錯誤：`Error: This is your first error!`

---

## 🎯 **完成 Sentry 設定**

### **在生產環境測試（推薦）**

因為 Sentry 只在生產環境啟用，所以要完整測試需要：

1. **部署到生產環境**
   ```bash
   gcloud builds submit --config=cloudbuild.yaml .
   gcloud run services update-traffic ichiban-frontend --to-latest --region us-central1
   ```

2. **打開生產網站**
   ```
   https://ichiban-frontend-72rputdqmq-uc.a.run.app
   ```

3. **觸發錯誤**
   - 按 `F12` 打開 Console
   - 輸入：`throw new Error('This is your first error!');`
   - 按 Enter

4. **查看 Sentry Dashboard**
   - 前往：https://sentry.io/
   - 點擊 "Issues"
   - 應該會看到錯誤報告！

5. **完成設定**
   - Sentry 會顯示「審我的錯誤」按鈕
   - 點擊完成設定流程

---

## 💡 **為什麼開發環境看不到 Sentry 錯誤？**

Sentry 配置為**只在生產環境啟用**：

```typescript
// utils/sentry.ts
const isProduction = import.meta.env.PROD;

export function initSentry() {
  if (!isProduction) {
    console.log('[Sentry] 開發環境，跳過初始化');
    return;
  }
  // ... Sentry 初始化
}
```

**原因：**
- 開發環境會有很多測試錯誤
- 避免消耗 Sentry 配額
- 只在真實用戶環境監控錯誤

---

## 🚀 **建議的測試流程**

### **選項 A：立即部署測試（推薦）**
```bash
# 1. 部署
gcloud builds submit --config=cloudbuild.yaml .
gcloud run services update-traffic ichiban-frontend --to-latest --region us-central1

# 2. 打開生產網站並測試
# 3. 查看 Sentry Dashboard
```

### **選項 B：先在開發環境確認功能**
1. ✅ 確認測試按鈕顯示正常
2. ✅ 確認點擊按鈕會觸發錯誤
3. ✅ 確認 Console 顯示錯誤訊息
4. 然後再部署到生產環境測試 Sentry

---

## 📝 **當前狀態**

- ✅ 前端開發伺服器：http://localhost:5173
- ✅ 後端開發伺服器：http://localhost:8080
- ✅ Sentry DSN：已配置
- ✅ 測試按鈕：已添加
- ⏳ Sentry 驗證：需要在生產環境完成

---

**需要我幫你部署到生產環境嗎？** 🚀
