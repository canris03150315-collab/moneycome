# 數據遷移腳本說明

## 📋 **可用腳本**

### **1. add-pool-verification-data.js**
為所有商品添加公平性驗證資訊

**用途**：
- 為新商品生成 poolCommitmentHash 和 prizeOrder
- 為已售完的商品公開 poolSeed

**執行**：
```bash
node backend/migrations/add-pool-verification-data.js
```

**注意**：
- 只會處理沒有驗證資訊的商品
- 已有驗證資訊的商品會被跳過

---

### **2. check-lottery-state.js**
檢查特定商品的狀態

**用途**：
- 查看商品的售完狀態
- 檢查是否有 poolSeed
- 診斷問題

**執行**：
```bash
# 檢查特定商品
node backend/migrations/check-lottery-state.js <商品ID>

# 例如
node backend/migrations/check-lottery-state.js set-1764336937045-71euc74
```

**輸出示例**：
```
檢查商品: set-1764336937045-71euc74

商品標題: DDD
prizeOrder 長度: 11
poolCommitmentHash: ✓ 存在
poolSeed: ✗ 不存在

抽獎狀態:
drawnTicketIndices 長度: 10

售完狀態:
已抽: 10 / 11 (剩餘 1 張)
是否售完: ✗ 否

- 商品未售完
```

---

### **3. publish-pool-seed.js**
公開籤池種子碼

**用途**：
- 為接近售完或已售完的商品公開種子碼
- 支持單個公開或批量公開

**執行**：
```bash
# 公開特定商品（剩餘 ≤ 1 張）
node backend/migrations/publish-pool-seed.js <商品ID>

# 強制公開（無論剩餘多少張）
node backend/migrations/publish-pool-seed.js <商品ID> --force

# 批量公開所有接近售完的商品（剩餘 ≤ 1 張）
node backend/migrations/publish-pool-seed.js --all
```

**示例**：
```bash
# 公開單個商品
node backend/migrations/publish-pool-seed.js set-1764336937045-71euc74

# 批量公開
node backend/migrations/publish-pool-seed.js --all
```

**輸出示例**：
```
處理商品: set-1764336937045-71euc74

商品標題: DDD
售完狀態: 10 / 11 (剩餘 1 張)

✓ 已生成並公開種子碼
新的 poolCommitmentHash: 65bd0c124e8eeef3...
poolSeed: 96bacf432e38ccf4...
```

---

## 🔄 **工作流程**

### **新商品上架時**
1. 商品創建時自動生成驗證資訊（如果後端支持）
2. 或者運行 `add-pool-verification-data.js` 手動生成

### **商品接近售完時**
1. 使用 `check-lottery-state.js` 檢查狀態
2. 如果剩餘 ≤ 1 張，運行 `publish-pool-seed.js` 公開種子碼

### **批量處理**
1. 運行 `publish-pool-seed.js --all` 批量公開所有接近售完的商品

---

## ⚠️ **注意事項**

### **關於 poolSeed**
- **應該在商品創建時就生成**，但不公開
- **只在售完後才公開**
- 如果商品創建時沒有生成，`publish-pool-seed.js` 會生成新的並更新 Hash

### **關於 poolCommitmentHash**
- 必須在開賣前就公開
- 用於證明籤池順序在開賣前已固定
- 如果後來更新了 poolSeed，Hash 也必須同步更新

### **售完判斷**
- 系統判斷：`drawnTickets >= totalTickets`
- 實際情況：可能剩餘 1 張（最後賞）
- 建議：剩餘 ≤ 1 張時就可以公開種子碼

---

## 🛠️ **故障排除**

### **問題：商品已售完但沒有種子碼**
**解決**：
```bash
node backend/migrations/publish-pool-seed.js <商品ID> --force
```

### **問題：不確定商品狀態**
**解決**：
```bash
node backend/migrations/check-lottery-state.js <商品ID>
```

### **問題：批量公開失敗**
**解決**：
1. 檢查 Firestore 連接
2. 檢查權限
3. 逐個商品手動公開

---

## 📝 **腳本執行記錄**

### **2025-11-30**
- ✅ 執行 `add-pool-verification-data.js` - 6 個商品已更新
- ✅ 執行 `publish-pool-seed.js --all` - 4 個商品已公開種子碼
  - set-1764336937045-71euc74 (DDD) - 剩餘 1 張
  - set-1764337070300-a5f3u3s (DDD) - 剩餘 1 張
  - set-1764337259318-u5wilg9 (DDDD) - 剩餘 1 張
  - set-1764337298183-hz1txmz (DDDD) - 剩餘 1 張

---

## 🔐 **安全性**

- ✅ 種子碼只在售完後公開
- ✅ Hash 在開賣前就已公開
- ✅ 用戶可以驗證整個過程的公平性
- ✅ 所有操作都有日誌記錄
